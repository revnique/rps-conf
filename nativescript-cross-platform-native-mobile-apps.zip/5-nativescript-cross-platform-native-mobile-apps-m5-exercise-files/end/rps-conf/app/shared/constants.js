"use strict";
exports.AZURE_URL = 'https://rpsdataservice2.azurewebsites.net/';
exports.AZURE_TABLE_PATH = 'api/';
exports.AZURE_TABLE_NAME = 'session';
exports.AZURE_VERSION_HEADER = { 'ZUMO-API-VERSION': '2.0.0' };
exports.LOADING_ERROR = 'Could not load sessions. Check your Internet connection and try again.';
//# sourceMappingURL=constants.js.map