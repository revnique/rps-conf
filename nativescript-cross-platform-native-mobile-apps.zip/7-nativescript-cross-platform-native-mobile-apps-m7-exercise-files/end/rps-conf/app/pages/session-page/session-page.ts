import { EventData } from 'data/observable';
import { GestureEventData, SwipeGestureEventData, SwipeDirection } from 'ui/gestures';
import { Page, NavigatedData } from 'ui/page';
import { Button } from 'ui/button';
import { Label } from 'ui/label';
import { ScrollView } from 'ui/scroll-view';
import { SessionViewModel } from '../session-page/session-view-model';

import * as navigationModule from '../../shared/navigation';
import * as animationHelperModule from '../../shared/animation-helper';

var vm: SessionViewModel;
var page: Page;

export function pageNavigatingTo(args: NavigatedData) {
    page = <Page>args.object;
    vm = args.context;
    page.bindingContext = vm;
} 

export function toggleFavorite(args) {
    var gl = <any>args.object;
    var img = gl.getViewById('imgFav');
    
    animationHelperModule.popAnimate(img)
        .then(() => {
            vm.toggleFavorite();
        });
}

export function toggleDescription(args: EventData) {
    var btn = <Button>args.object;
    var txtDesc = <Label>page.getViewById('txtDescription');
    var scroll = <ScrollView>page.getViewById('scroll');

    if (btn.text === 'MORE') {
        btn.text = 'LESS';
        txtDesc.text = vm.description;
    }
    else {
        btn.text = 'MORE';
        txtDesc.text = vm.descriptionShort;
        scroll.scrollToVerticalOffset(0, false);
    }
}

export function backTap(args: GestureEventData) {
    navigationModule.goBack();
}

export function showMapTap(args: GestureEventData) {
    navigationModule.goToRoomMapPage(vm);
}

export function backSwipe(args: SwipeGestureEventData) {
    if (args.direction === SwipeDirection.right) {
        navigationModule.goBack();
    }
}