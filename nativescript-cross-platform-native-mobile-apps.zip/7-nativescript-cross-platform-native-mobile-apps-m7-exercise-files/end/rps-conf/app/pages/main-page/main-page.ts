import { EventData } from 'data/observable';
import { GestureEventData } from 'ui/gestures';
import { ItemEventData } from 'ui/list-view';
import { Page } from 'ui/page';
import { Button } from 'ui/button';
import { MainViewModel } from './main-view-model';
import { SessionViewModel } from '../session-page/session-view-model';

import * as navigationModule from '../../shared/navigation';
import * as animationHelperModule from '../../shared/animation-helper';

var vm = new MainViewModel();
var page: Page;
var SIDE_DRAWER_ID = 'SideDrawer';

export function pageLoaded(args: EventData) {
    page = <Page>args.object;
    page.bindingContext = vm;
    vm.init();
}

export function selectSession(args: ItemEventData) {
    var session = <SessionViewModel>args.view.bindingContext;

    if (!session.isBreak) {
        navigationModule.gotoSessionPage(session);
    }
}

export function selectView(args: EventData) {
    var btn = <Button>args.object;
    var slideBar = <any>page.getViewById(SIDE_DRAWER_ID);
    slideBar.closeDrawer();

    vm.selectView(parseInt((<any>btn).tag), btn.text);
}

export function toggleFavorite(args: GestureEventData) {
    var session = <SessionViewModel>args.view.bindingContext;
    var gl = <any>args.object;
    var img = gl.getViewById('imgFav');
    
    animationHelperModule.popAnimate(img)
        .then(() => {
            session.toggleFavorite();
        });
    
}

export function showSlideout(args: GestureEventData) {
    var slideBar = <any>page.getViewById(SIDE_DRAWER_ID);
    slideBar.showDrawer();
}
