"use strict";
var enums_1 = require('ui/enums');
var duration = 250;
var scaleFactor = 1.8;
function fadeZoom(view) {
    return view.animate({
        duration: 3000,
        opacity: 1.0,
        scale: { x: 1.0, y: 1.0 }
    });
}
exports.fadeZoom = fadeZoom;
function popAnimate(view) {
    var defPopUp = {
        duration: duration,
        scale: { x: scaleFactor, y: scaleFactor },
        curve: enums_1.AnimationCurve.easeIn
    };
    var defPopDown = {
        duration: duration,
        scale: { x: 1.0, y: 1.0 },
        curve: enums_1.AnimationCurve.easeOut
    };
    return view.animate(defPopUp)
        .then(function () {
        view.animate(defPopDown);
    });
}
exports.popAnimate = popAnimate;
//# sourceMappingURL=animation-helper.js.map