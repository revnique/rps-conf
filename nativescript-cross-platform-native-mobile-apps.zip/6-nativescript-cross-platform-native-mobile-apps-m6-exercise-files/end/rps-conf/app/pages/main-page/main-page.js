"use strict";
var main_view_model_1 = require('./main-view-model');
var navigationModule = require('../../shared/navigation');
var vm = new main_view_model_1.MainViewModel();
var page;
var SIDE_DRAWER_ID = 'SideDrawer';
function pageLoaded(args) {
    page = args.object;
    page.bindingContext = vm;
    vm.init();
}
exports.pageLoaded = pageLoaded;
function selectSession(args) {
    var session = args.view.bindingContext;
    if (!session.isBreak) {
        navigationModule.gotoSessionPage(session);
    }
}
exports.selectSession = selectSession;
function selectView(args) {
    var btn = args.object;
    var slideBar = page.getViewById(SIDE_DRAWER_ID);
    slideBar.closeDrawer();
    vm.selectView(parseInt(btn.tag), btn.text);
}
exports.selectView = selectView;
function toggleFavorite(args) {
    var session = args.view.bindingContext;
    session.toggleFavorite();
}
exports.toggleFavorite = toggleFavorite;
function showSlideout(args) {
    var slideBar = page.getViewById(SIDE_DRAWER_ID);
    slideBar.showDrawer();
}
exports.showSlideout = showSlideout;
//# sourceMappingURL=main-page.js.map