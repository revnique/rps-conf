import { Observable } from 'data/observable';
import { Session, ConferenceDay } from '../../shared/interfaces'
import { SessionViewModel } from '../session-page/session-view-model';
import { SessionsService } from '../../services/sessions-service';
import { conferenceDays } from '../../shared/static-data';


export class MainViewModel extends Observable {
    private _selectedIndex;
    private _allSessions: Array<SessionViewModel> = new Array<SessionViewModel>();
    private _sessions: Array<SessionViewModel>;
    private _sessionsService: SessionsService;
    
    public selectedViewIndex: number;
    
    constructor() {
        super();
        this._sessionsService = new SessionsService();
        this.selectedIndex = 0;
        this.selectedViewIndex = 1;
        this.set('actionBarTitle', 'All sessions');
        this.set('isLoading', true);
        this.set('isSessionsPage', true);
    }
    
    get confDayOptions(): Array<ConferenceDay> {
        return conferenceDays;
    }
    
    get sessions(): Array<SessionViewModel> {
        return this._sessions;
    }
    
    get selectedIndex(): number {
        return this._selectedIndex;
    }
    
    set selectedIndex(value: number) {
        if (this._selectedIndex !== value) {
            this._selectedIndex = value;
            this.notify({ object: this, eventName: Observable.propertyChangeEvent, propertyName: "selectedIndex", value: value });

            this.set('dayHeader', conferenceDays[value].desc);
            this.filter();
        }
    }
    
    public init() {
       this._sessionsService.loadSessions<Array<Session>>()
           .then((result: Array<Session>)=>{
               this.pushSessions(result);
               this.onDataLoaded();
           });
    }
    
    private pushSessions(sessionsFromService: Array<Session>) {
        for (var i = 0; i < sessionsFromService.length; i++) {
            var newSession = new SessionViewModel(sessionsFromService[i]);
            this._allSessions.push(newSession);
        }
    }
    
    private onDataLoaded() {
        this.set('isLoading', false);
        this.filter();
    }
    
    private filter() {
        this._sessions = this._allSessions.filter(s=> {
            return s.startDt.getDate() === conferenceDays[this.selectedIndex].date.getDate();
        });

        if (this.selectedViewIndex === 0) {
            this._sessions = this._sessions.filter(i=> { return i.favorite || i.isBreak; });
        }

        this.notify({ object: this, eventName: Observable.propertyChangeEvent, propertyName: "sessions", value: this._sessions });
    }

    public selectView(index: number, titleText: string) {
        this.selectedViewIndex = index;
        if (this.selectedViewIndex < 2) {
            this.filter();
        }
        this.notify({ object: this, eventName: Observable.propertyChangeEvent, propertyName: "selectedViewIndex", value: this.selectedViewIndex });
        this.set('actionBarTitle', titleText);
        this.set('isSessionsPage', this.selectedViewIndex < 2);
    }
}