import { Page, NavigatedData } from 'ui/page';
import { GestureEventData, SwipeGestureEventData, SwipeDirection } from 'ui/gestures';
import { RoomInfo } from '../../shared/interfaces';
import { MapViewModel } from '../map-page/map-view-model';

import * as roomMapsServiceModule from '../../services/room-map-service';
import * as navigationModule from '../../shared/navigation';

var vm: MapViewModel;

export function pageNavigatingTo(args: NavigatedData) {
    var page = <Page>args.object;
    
    if (!page || !page.navigationContext)
        return;
        
    vm = new MapViewModel(<RoomInfo>page.navigationContext.roomInfo);
    vm.isLoading = true;
    
    roomMapsServiceModule.getRoomImage(vm.roomInfo, function (imageSource) {
        vm.set('image', imageSource);
        vm.isLoading = false;
    });

    page.bindingContext = vm;
}

export function backTap(args: GestureEventData) {
    navigationModule.goBack();
}

export function backSwipe(args: SwipeGestureEventData) {
    if (args.direction === SwipeDirection.right) {
        navigationModule.goBack();
    }
}