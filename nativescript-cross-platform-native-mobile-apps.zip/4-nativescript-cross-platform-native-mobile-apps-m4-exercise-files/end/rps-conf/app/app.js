"use strict";
var application = require("application");
application.cssFile = 'styles/app.css';
application.start({ moduleName: "pages/main-page/main-page" });
//# sourceMappingURL=app.js.map