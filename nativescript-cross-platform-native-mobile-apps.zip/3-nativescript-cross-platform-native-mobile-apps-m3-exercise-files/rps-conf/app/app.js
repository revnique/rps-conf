"use strict";
var application = require("application");
application.start({ moduleName: "main-page" });
//# sourceMappingURL=app.js.map