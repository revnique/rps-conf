import application = require("application");
application.start({ moduleName: "main-page" });
